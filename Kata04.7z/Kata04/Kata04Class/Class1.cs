﻿namespace Kata04Class;

public class WeatherFootBallProgram
{
    public static string FindMin(string filePath)
    {
        string[] lines = File.ReadAllLines(filePath);

        int minTemp = int.MaxValue;
        int minTempDay = -1;

        for (int i = 1; i<lines.Length; i++ )
        {
            string line = lines[i].Trim();
            if (string.IsNullOrEmpty(line) || line.StartsWith("mo")) continue;

            string[] parts = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length < 3)continue;

            if(int.TryParse(parts[0], out int day)&& int.TryParse(parts[2].TrimEnd('*'), out int minTempCurrent))
            {
                if (minTempCurrent < minTemp)
                {
                    minTemp = minTempCurrent;
                    minTempDay = day;
                }
            }
        }

        return minTempDay.ToString();
    }

    public static string FindMinFoot(string filePath)
    {
        string[] lines = File.ReadAllLines(filePath);
        string teamMin = " ";
        int minDiff = int.MaxValue;

        foreach (var line in lines.Skip(1))
        {
            if (string.IsNullOrEmpty(line)) continue;
            string[] parts = line.Split(new [] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length < 8) continue;

            string teamName = parts[1];
            int goalsFor = int.Parse(parts[6]);
            int goalsAgainst = int.Parse(parts [8]);

            int goalsDiff = Math.Abs(goalsFor - goalsAgainst);

            if (goalsDiff < minDiff)
            {
                minDiff = goalsDiff;
                teamMin = teamName;
            }
        }
        
        return teamMin;
    }
}

public abstract class FileProcessor
{
    public static string[] ReadLines(string filePath)
    {
        return File.ReadAllLines(filePath);
    }

    public abstract string ProcessFile(string filePath);
}

public class Weather : FileProcessor
{
    public override string ProcessFile(string filePath)
    {
        return ProcessWeatherFile(filePath);
    }

    public static string ProcessWeatherFile(string filePath)
    {
        string[] lines = File.ReadAllLines(filePath);

        int minTemp = int.MaxValue;
        int minTempDay = -1;

        for (int i = 1; i<lines.Length; i++ )
        {
            string line = lines[i].Trim();
            if (string.IsNullOrEmpty(line) || line.StartsWith("mo")) continue;

            string[] parts = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length < 3)continue;

            if(int.TryParse(parts[0], out int day)&& int.TryParse(parts[2].TrimEnd('*'), out int minTempCurrent))
            {
                if (minTempCurrent < minTemp)
                {
                    minTemp = minTempCurrent;
                    minTempDay = day;
                }
            }
        }

        return minTempDay.ToString();
    }
}

public class FootBall : FileProcessor
{
    public override string ProcessFile(string filePath)
    {
        return ProcessFootBallFile(filePath);
    }

    public static string ProcessFootBallFile(string filePath)
    {
        string[] lines = File.ReadAllLines(filePath);
        string teamMin = " ";
        int minDiff = int.MaxValue;

        foreach (var line in lines.Skip(1))
        {
            if (string.IsNullOrEmpty(line)) continue;
            string[] parts = line.Split(new [] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length < 8) continue;

            string teamName = parts[1];
            int goalsFor = int.Parse(parts[6]);
            int goalsAgainst = int.Parse(parts [8]);

            int goalsDiff = Math.Abs(goalsFor - goalsAgainst);

            if (goalsDiff < minDiff)
            {
                minDiff = goalsDiff;
                teamMin = teamName;
            }
        }
        
        return teamMin;
    }
}


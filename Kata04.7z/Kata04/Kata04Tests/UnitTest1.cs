namespace Kata04Tests;

[TestClass]
public class UnitTest1
{
    [TestMethod]
    public void FindMinWeather()
    {
        string filePath = "C:\\Users\\WinterTreat\\Desktop\\Kata04\\weather.dat";
        string result = Kata04Class.WeatherFootBallProgram.FindMin(filePath);
        Assert.AreEqual("9", result);
    }

    [TestMethod]
    public void FindMinFootball()
    {
        string filePath = "C:\\Users\\WinterTreat\\Desktop\\Kata04\\football.dat";
        string result = Kata04Class.WeatherFootBallProgram.FindMinFoot(filePath);
        Assert.AreEqual("Aston_Villa", result);
    }

    [TestMethod]
    public void FindMinWeather2()
    {
        string filePath = "C:\\Users\\WinterTreat\\Desktop\\Kata04\\weather.dat";
        string result = Kata04Class.Weather.ProcessWeatherFile(filePath);
        Assert.AreEqual("9", result);
    }

    [TestMethod]
    public void FindMinFootball2()
    {
        string filePath = "C:\\Users\\WinterTreat\\Desktop\\Kata04\\football.dat";
        string result = Kata04Class.FootBall.ProcessFootBallFile(filePath);
        Assert.AreEqual("Aston_Villa", result);
    }


}